export * from './patientRegisterPage';
