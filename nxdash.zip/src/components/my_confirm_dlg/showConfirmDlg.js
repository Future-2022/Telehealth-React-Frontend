import ConfirmDlg from "./ConfirmDlg";
import {createConfirmation} from 'react-confirm';

export const showConfirm = createConfirmation(ConfirmDlg);