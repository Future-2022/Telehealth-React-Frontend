export * from './userDetailPage';
