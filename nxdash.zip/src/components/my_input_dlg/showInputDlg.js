import {createConfirmation} from 'react-confirm';
import MyInputDlg from './MyInputDlg';

export const showInputDlg = createConfirmation(MyInputDlg);