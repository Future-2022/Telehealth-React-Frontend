export * from './settingPage';
