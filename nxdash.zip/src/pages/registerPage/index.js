export * from './registerPage';
