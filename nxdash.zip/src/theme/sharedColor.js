export const sharedColors = {
    primaryFontColor: '#39D3E3',
    primaryButtonsColor: '#4939E3',
    primaryButtonGradientStart: '#877CEC',
    primaryButtonGradientEnd: '#4939E3',
}