import MyAlertDlg from "./MyAlertDlg";
import { createConfirmation } from 'react-confirm';

export const showAlert = createConfirmation(MyAlertDlg);