export * from './patientPage';
